# Here are all my details...

| Track    | Superset Id | College Name                                       | Name        | Email Id                 | 
|----------|-------------|----------------------------------------------------|-------------|--------------------------|
| Java FSE | 5018091     | University of Engineering and Management, Kolkata  | Subha Saha  | subhasaha202@gmail.com   |



