package com.library.repository;

import org.springframework.stereotype.Repository;

@Repository
public class BookRepository {
    // Repository methods
    public void someMethod() {
        // Method implementation
        System.out.println("Hi from BookRepository...");
    }
}


