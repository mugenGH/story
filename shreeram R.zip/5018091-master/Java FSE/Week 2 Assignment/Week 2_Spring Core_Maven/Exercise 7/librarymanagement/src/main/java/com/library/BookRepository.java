package com.library;

public class BookRepository {
    // Sample repository class
    public void saveBook() {
        System.out.println("Book saved");
    }
}
