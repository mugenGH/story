package com.library;

public class BookRepository {
    public void bookSave() {
        System.out.println("BookRepository.save() : Saving a book...");
    }
}
