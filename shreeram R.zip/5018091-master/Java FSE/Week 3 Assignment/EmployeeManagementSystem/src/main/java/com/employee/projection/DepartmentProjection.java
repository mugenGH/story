package com.employee.projection;

public interface DepartmentProjection {
    Long getId();

    String getName();

}
